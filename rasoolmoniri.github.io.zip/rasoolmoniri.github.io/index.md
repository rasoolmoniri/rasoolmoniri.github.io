﻿### Resume
```
 Rasool Moniri
```

![Logo](https://github.com/rasoolmoniri/rasoolmoniri.github.io/pic.png)

---

TEL  : 09364380464,
Mail : rmoniry@yahoo.com <br/>
Persian Resume : [link to Resume.](https://github.com/rasoolmoniri/rasoolmoniri.github.io/Resume_Fa.pdf) <br/>
jointomychannel : https://t.me/joinchat/AAAAAEubyejDgeCJYBxs5 <br/>
quera profile : https://quera.ir/profile/rmoniry

###Skill Highlights
---
+	Programming Languages (Pascal,C,C++,)

+	Agile/Lean/Scrum/Kanban/Scrumban

+	Database (MS SQL Server,Oracle, NO-SQL)

+	Data Structures and Algorithms

+	Virtualization	

+	PLC/OPC/IIoT

+	Data mining

+	Docker

###Working Experience
---
+ I WORK SOME TIMES IN SCHOOLS –  
    
###Education
---
+ Master of Science: Software Engineering
  - 2020TEHRANPAYAMENOORUNIVERSITY
+ Bachelor of Science: HARDware Engineering
  - 2011-2015, TEHRANPAYAMENOORUNIVERSITY, TEHRAN Branch
  
.
